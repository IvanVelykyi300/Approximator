﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovePoints : MonoBehaviour {

    public GameObject point;
    public GameObject line;
    private GameObject[] points;
    private LineRenderer lr1;
    private LineRenderer lr2;
    private int count;
	// Use this for initialization
	void Start () {
        points = new GameObject[5];
        count = 0;
        GameObject l = Instantiate(line);
        lr1 = l.GetComponent<LineRenderer>();
        l = Instantiate(line);
        lr2 = l.GetComponent<LineRenderer>();
        lr2.startColor = Color.green;
        lr2.endColor = Color.green;
    }
	
	void OnMouseDrag()
    {
        Vector3 pos = Camera.main.ScreenToWorldPoint (Input.mousePosition);
        if(pos.x > -6 && pos.x < 4)
        {
            pos.y = (pos.y < -4f) ? -4f : pos.y;
            pos.y = (pos.y > 3.5f) ? 3.5f : pos.y;
            int n = (int)(pos.x / 2 + 3);
            if (points[n] == null)
            {
                points[n] = Instantiate(point, new Vector2(n * 2 - 5, pos.y), Quaternion.identity);
                count++;
            }
            else points[n].transform.position = new Vector2(n * 2 - 5, pos.y);
            if(count == 5)
            {
                float a = 0, b = 0, c = 0, d = 0, e = 0;
                float[] kofs = new float[5];
                for(int i = 0; i < kofs.Length; i++)
                {
                    kofs[i] = points[i].transform.position.y;
                    for(int j = 0; j < kofs.Length; j++)
                    {
                        if (i != j) kofs[i] /= (points[i].transform.position.x - points[j].transform.position.x);
                    }
                }
                float tempd, tempe;
                for(int i = 0; i < kofs.Length; i++)
                {
                    a += kofs[i];
                    tempe = kofs[i];
                    for (int j = 0; j < kofs.Length; j++)
                    {
                        if (j != i)
                        {
                            b -= kofs[i] * points[j].transform.position.x;
                            tempd = kofs[i];
                            tempe *= points[j].transform.position.x;
                            for (int k = 0; k < kofs.Length; k++)
                            {
                                if (k != i)
                                {
                                    if (k > j) c += kofs[i] * points[j].transform.position.x * points[k].transform.position.x;
                                    if (k != j) tempd *= points[k].transform.position.x;
                                }
                            }
                            d -= tempd;
                        }
                    }
                    e += tempe;
                }
                int steps = 1000;
                float xmin = -7, xmax = 5;
                float x;
                Vector3[] pts = new Vector3[steps + 1];
                for (int i = 0; i < pts.Length; i++)
                {
                    x = xmin + (xmax - xmin) * i / steps;
                    pts[i] = new Vector3(x, a * Mathf.Pow(x, 4) + b * Mathf.Pow(x, 3) + c * Mathf.Pow(x, 2) + d * x + e);
                }
                lr1.positionCount = steps + 1;
                lr1.SetPositions(pts);
                float[,] matrix = new float[4, 4];
                float[] y = new float[4];
                for(int i = 0; i<matrix.GetLength(0); i++)
                {
                    y[i] = 0;
                    for (int j = 0; j < matrix.GetLength(0); j++)
                    {
                        matrix[i, j] = 0;
                        for(int k = 0; k < points.Length; k++)
                        {
                            matrix[i, j] += Mathf.Pow(points[k].transform.position.x, 3 - i) * Mathf.Pow(points[k].transform.position.x, 3 - j);
                            if (j == 0) y[i] += points[k].transform.position.y * Mathf.Pow(points[k].transform.position.x, 3 - i);
                        }
                    }
                }
                float det = Det(matrix);
                float[] z = new float[4];
                float[,] matr;
                for (int i = 0; i < z.Length; i++)
                {
                    matr = (float[,])matrix.Clone();
                    for (int j = 0; j < matr.GetLength(0); j++)
                    {
                        matr[j, i] = y[j];
                    }
                    z[i] = Det(matr) / det;
                }
                pts = new Vector3[steps + 1];
                for (int i = 0; i < pts.Length; i++)
                {
                    x = xmin + (xmax - xmin) * i / steps;
                    pts[i] = new Vector3(x, z[0] * Mathf.Pow(x, 3) + z[1] * Mathf.Pow(x, 2) + z[2] * x + z[3]);
                }
                lr2.positionCount = steps + 1;
                lr2.SetPositions(pts);
            }
        }
    }
    float Det(float[,] m)
    {
        if (m.GetLength(0) == 1) return m[0, 0];
        float det = 0;
        float[,] mm = new float[m.GetLength(0) - 1, m.GetLength(0) - 1];
        for (int i = 0; i < m.GetLength(0); i++)
        {
            for (int j = 0; j < mm.GetLength(0); j++)
            {
                for (int k = 0; k < mm.GetLength(0); k++)
                {
                    mm[j, k] = m[j + 1, (k >= i) ? k + 1 : k];
                }
            }
            det += ((i % 2 == 0) ? 1 : -1) * m[0, i] * Det(mm);
        }
        return det;
    }
}
